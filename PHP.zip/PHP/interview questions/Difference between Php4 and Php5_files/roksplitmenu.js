/**
 * RokSplitMenu - MooTools script for collapsing split menus
 * 
 * @version		1.0
 * 
 * @author		Djamil Legato <djamil@rockettheme.com>
 * @copyright	Andy Miller @ Rockettheme, LLC
*/

eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--){d[e(c)]=k[c]||e(c)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('2 w=e x({\'9\':{\'t\':\'8.6\'},y:3(9){0.z(9);0.r=$$(0.9.t);0.m=[];0.r.j(3(6){2 d=6.F().E(3(p){B p.g(\'d\')});i(d.C)0.m.D(d)},0);0.q()},q:3(){2 h=0;0.m.j(3(6){6.j(3(4){2 8=4.A(\'8\');2 f=4.n(\'a\').n(\'f\');i(f)f.s(\'T\',\'S\');2 7=e R.U(8)[4.g(\'o\')?\'V\':\'Y\']();2 b=e G(\'b\',{\'W\':4.g(\'o\')?\'5-1-c\':\'5-1-k\'}).Q(4.s(\'P\',\'J\'),\'I\');b.H(\'K\',h.l.L(h,[7,b]))})})},l:3(O,7,1){7.l();i(!!!7.c)1.u(\'5-1-k\').v(\'5-1-c\');N 1.u(\'5-1-c\').v(\'5-1-k\')}});w.M(e X);',61,61,'this|arrow|var|function|element|split|menu|slide|ul|options||div|open|parent|new|span|hasClass|self|if|each|close|toggle|elements|getFirst|active|el|htmlize|menus|setStyle|menuClass|removeClass|addClass|RokSplitMenu|Class|initialize|setOptions|getElement|return|length|push|filter|getChildren|Element|addEvent|top|relative|click|bindWithEvent|implement|else|event|position|inject|Fx|none|background|Slide|show|class|Options|hide'.split('|'),0,{}))
